// Zalacz plik naglowkowy defs.h maksymalnie raz
#pragma once

// Deklaracja zmienny, extern - zmienne są zdefiniowane gdzie indziej
extern float x;
extern float y;

// Deklaracja funkcji
float add(float x, float y);