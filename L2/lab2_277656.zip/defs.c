// Zalacz plik naglowkowy defs.h
#include "defs.h"

// Definicja zmiennych
float x = 2.25;
float y = 2.75;

// Definicja funkcji
float add(float x, float y){
    return x + y;
}